<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<xsl:stylesheet xmlns:xs="http://www.w3.org/2001/XMLSchema"
                xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                xmlns:saxon="http://saxon.sf.net/"
                xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
                xmlns:schold="http://www.ascc.net/xml/schematron"
                xmlns:iso="http://purl.oclc.org/dsdl/schematron"
                xmlns:xhtml="http://www.w3.org/1999/xhtml"
                xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
                xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
                xmlns:cec="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2"
                xmlns:pxs="urn:peppol:schema:vida-taxdata:1.0"
                xmlns:inv="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
                xmlns:cn="urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2"
                xmlns:pxc="urn:peppol:xslt:custom-function"
                version="2.0"><!--Implementers: please note that overriding process-prolog or process-root is 
    the preferred method for meta-stylesheets to use where possible. -->
   <xsl:param name="archiveDirParameter"/>
   <xsl:param name="archiveNameParameter"/>
   <xsl:param name="fileNameParameter"/>
   <xsl:param name="fileDirParameter"/>
   <xsl:variable name="document-uri">
      <xsl:value-of select="document-uri(/)"/>
   </xsl:variable>
   <!--PHASES-->
   <!--PROLOG-->
   <xsl:output xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
               method="xml"
               omit-xml-declaration="no"
               standalone="yes"
               indent="yes"/>
   <!--XSD TYPES FOR XSLT2-->
   <!--KEYS AND FUNCTIONS-->
   <xsl:function xmlns="http://purl.oclc.org/dsdl/schematron"
                 name="pxc:genPath"
                 as="xs:string">
      <xsl:param name="node" as="node()"/>
      <xsl:sequence select="         string-join(for $ancestor in $node/ancestor-or-self::node()                     return                       if ($ancestor instance of element())                       then concat('/',                                   name($ancestor),                                   if (   count($ancestor/preceding-sibling::*[name() = name($ancestor)]) &gt;    0                                       or count($ancestor/following-sibling::*[name() = name($ancestor)]) &gt; 0)                                   then concat('[', count($ancestor/preceding-sibling::*[name() = name($ancestor)]) + 1, ']')                                   else ''                                   )                       else                         if ($ancestor instance of attribute())                         then concat('/@', name($ancestor))                         else ''                     , '')     "/>
   </xsl:function>
   <!--DEFAULT RULES-->
   <!--MODE: SCHEMATRON-SELECT-FULL-PATH-->
   <!--This mode can be used to generate an ugly though full XPath for locators-->
   <xsl:template match="*" mode="schematron-select-full-path">
      <xsl:apply-templates select="." mode="schematron-get-full-path"/>
   </xsl:template>
   <!--MODE: SCHEMATRON-FULL-PATH-->
   <!--This mode can be used to generate an ugly though full XPath for locators-->
   <xsl:template match="*" mode="schematron-get-full-path">
      <xsl:apply-templates select="parent::*" mode="schematron-get-full-path"/>
      <xsl:text>/</xsl:text>
      <xsl:choose>
         <xsl:when test="namespace-uri()=''">
            <xsl:value-of select="name()"/>
         </xsl:when>
         <xsl:otherwise>
            <xsl:text>*:</xsl:text>
            <xsl:value-of select="local-name()"/>
            <xsl:text>[namespace-uri()='</xsl:text>
            <xsl:value-of select="namespace-uri()"/>
            <xsl:text>']</xsl:text>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:variable name="preceding"
                    select="count(preceding-sibling::*[local-name()=local-name(current())                                   and namespace-uri() = namespace-uri(current())])"/>
      <xsl:text>[</xsl:text>
      <xsl:value-of select="1+ $preceding"/>
      <xsl:text>]</xsl:text>
   </xsl:template>
   <xsl:template match="@*" mode="schematron-get-full-path">
      <xsl:apply-templates select="parent::*" mode="schematron-get-full-path"/>
      <xsl:text>/</xsl:text>
      <xsl:choose>
         <xsl:when test="namespace-uri()=''">@<xsl:value-of select="name()"/>
         </xsl:when>
         <xsl:otherwise>
            <xsl:text>@*[local-name()='</xsl:text>
            <xsl:value-of select="local-name()"/>
            <xsl:text>' and namespace-uri()='</xsl:text>
            <xsl:value-of select="namespace-uri()"/>
            <xsl:text>']</xsl:text>
         </xsl:otherwise>
      </xsl:choose>
   </xsl:template>
   <!--MODE: SCHEMATRON-FULL-PATH-2-->
   <!--This mode can be used to generate prefixed XPath for humans-->
   <xsl:template match="node() | @*" mode="schematron-get-full-path-2">
      <xsl:for-each select="ancestor-or-self::*">
         <xsl:text>/</xsl:text>
         <xsl:value-of select="name(.)"/>
         <xsl:if test="preceding-sibling::*[name(.)=name(current())]">
            <xsl:text>[</xsl:text>
            <xsl:value-of select="count(preceding-sibling::*[name(.)=name(current())])+1"/>
            <xsl:text>]</xsl:text>
         </xsl:if>
      </xsl:for-each>
      <xsl:if test="not(self::*)">
         <xsl:text/>/@<xsl:value-of select="name(.)"/>
      </xsl:if>
   </xsl:template>
   <!--MODE: SCHEMATRON-FULL-PATH-3-->
   <!--This mode can be used to generate prefixed XPath for humans 
	(Top-level element has index)-->
   <xsl:template match="node() | @*" mode="schematron-get-full-path-3">
      <xsl:for-each select="ancestor-or-self::*">
         <xsl:text>/</xsl:text>
         <xsl:value-of select="name(.)"/>
         <xsl:if test="parent::*">
            <xsl:text>[</xsl:text>
            <xsl:value-of select="count(preceding-sibling::*[name(.)=name(current())])+1"/>
            <xsl:text>]</xsl:text>
         </xsl:if>
      </xsl:for-each>
      <xsl:if test="not(self::*)">
         <xsl:text/>/@<xsl:value-of select="name(.)"/>
      </xsl:if>
   </xsl:template>
   <!--MODE: GENERATE-ID-FROM-PATH -->
   <xsl:template match="/" mode="generate-id-from-path"/>
   <xsl:template match="text()" mode="generate-id-from-path">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:value-of select="concat('.text-', 1+count(preceding-sibling::text()), '-')"/>
   </xsl:template>
   <xsl:template match="comment()" mode="generate-id-from-path">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:value-of select="concat('.comment-', 1+count(preceding-sibling::comment()), '-')"/>
   </xsl:template>
   <xsl:template match="processing-instruction()" mode="generate-id-from-path">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:value-of select="concat('.processing-instruction-', 1+count(preceding-sibling::processing-instruction()), '-')"/>
   </xsl:template>
   <xsl:template match="@*" mode="generate-id-from-path">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:value-of select="concat('.@', name())"/>
   </xsl:template>
   <xsl:template match="*" mode="generate-id-from-path" priority="-0.5">
      <xsl:apply-templates select="parent::*" mode="generate-id-from-path"/>
      <xsl:text>.</xsl:text>
      <xsl:value-of select="concat('.',name(),'-',1+count(preceding-sibling::*[name()=name(current())]),'-')"/>
   </xsl:template>
   <!--MODE: GENERATE-ID-2 -->
   <xsl:template match="/" mode="generate-id-2">U</xsl:template>
   <xsl:template match="*" mode="generate-id-2" priority="2">
      <xsl:text>U</xsl:text>
      <xsl:number level="multiple" count="*"/>
   </xsl:template>
   <xsl:template match="node()" mode="generate-id-2">
      <xsl:text>U.</xsl:text>
      <xsl:number level="multiple" count="*"/>
      <xsl:text>n</xsl:text>
      <xsl:number count="node()"/>
   </xsl:template>
   <xsl:template match="@*" mode="generate-id-2">
      <xsl:text>U.</xsl:text>
      <xsl:number level="multiple" count="*"/>
      <xsl:text>_</xsl:text>
      <xsl:value-of select="string-length(local-name(.))"/>
      <xsl:text>_</xsl:text>
      <xsl:value-of select="translate(name(),':','.')"/>
   </xsl:template>
   <!--Strip characters-->
   <xsl:template match="text()" priority="-1"/>
   <!--SCHEMA SETUP-->
   <xsl:template match="/">
      <svrl:schematron-output xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                              title="OpenPeppol Slovak Republic TDD Schematron"
                              schemaVersion="">
         <xsl:comment>
            <xsl:value-of select="$archiveDirParameter"/>   
		 <xsl:value-of select="$archiveNameParameter"/>  
		 <xsl:value-of select="$fileNameParameter"/>  
		 <xsl:value-of select="$fileDirParameter"/>
         </xsl:comment>
         <svrl:text>These are the Schematron rules for the OpenPeppol Slovak Republic TDD.

		Author:
      		Susheel Kumar
	</svrl:text>
         <svrl:ns-prefix-in-attribute-values uri="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
                                             prefix="cac"/>
         <svrl:ns-prefix-in-attribute-values uri="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
                                             prefix="cbc"/>
         <svrl:ns-prefix-in-attribute-values uri="urn:oasis:names:specification:ubl:schema:xsd:CommonExtensionComponents-2"
                                             prefix="cec"/>
         <svrl:ns-prefix-in-attribute-values uri="urn:peppol:schema:vida-taxdata:1.0" prefix="pxs"/>
         <svrl:ns-prefix-in-attribute-values uri="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
                                             prefix="inv"/>
         <svrl:ns-prefix-in-attribute-values uri="urn:oasis:names:specification:ubl:schema:xsd:CreditNote-2"
                                             prefix="cn"/>
         <svrl:ns-prefix-in-attribute-values uri="urn:peppol:xslt:custom-function" prefix="pxc"/>
         <svrl:active-pattern>
            <xsl:attribute name="document">
               <xsl:value-of select="document-uri(/)"/>
            </xsl:attribute>
            <xsl:attribute name="id">default</xsl:attribute>
            <xsl:attribute name="name">default</xsl:attribute>
            <xsl:apply-templates/>
         </svrl:active-pattern>
         <xsl:apply-templates select="/" mode="M10"/>
      </svrl:schematron-output>
   </xsl:template>
   <!--SCHEMATRON PATTERNS-->
   <svrl:text xmlns:svrl="http://purl.oclc.org/dsdl/svrl">OpenPeppol Slovak Republic TDD Schematron</svrl:text>
   <!--PATTERN default-->
   <xsl:variable name="cl_dtc" select="' S R D '"/>
   <xsl:variable name="cl_ds" select="' D IC INTL '"/>
   <xsl:variable name="cl_rr" select="' C2 C3 '"/>
   <xsl:variable name="cl_currency"
                 select="' AED AFN ALL AMD ANG AOA ARS AUD AWG AZN BAM BBD BDT BGN BHD BIF BMD BND BOB BOV BRL BSD BTN BWP BYN BZD CAD CDF CHE CHF CHW CLF CLP CNY COP COU CRC CUP CVE CZK DJF DKK DOP DZD EGP ERN ETB EUR FJD FKP GBP GEL GHS GIP GMD GNF GTQ GYD HKD HNL HTG HUF IDR ILS INR IQD IRR ISK JMD JOD JPY KES KGS KHR KMF KPW KRW KWD KYD KZT LAK LBP LKR LRD LSL LYD MAD MDL MGA MKD MMK MNT MOP MRU MUR MVR MWK MXN MXV MYR MZN NAD NGN NIO NOK NPR NZD OMR PAB PEN PGK PHP PKR PLN PYG QAR RON RSD RUB RWF SAR SBD SCR SDG SEK SGD SHP SLE SOS SRD SSP STD SVC SYP SZL THB TJS TMT TND TOP TRY TTD TWD TZS UAH UGX USD USN UYI UYU UYW UZS VED VES VND VUV WST XAF XAG XAU XBA XBB XBC XBD XCD XDR XOF XPD XPF XPT XSU XTS XUA YER ZAR ZMW ZWG XXX CNH '"/>
   <xsl:variable name="regex_pidscheme" select="'^[0-9]{4}$'"/>
   <!--RULE -->
   <xsl:template match="/pxs:TaxData" priority="1051" mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl" context="/pxs:TaxData"/>
      <xsl:variable name="dtc" select="normalize-space(pxs:DocumentTypeCode)"/>
      <xsl:variable name="ds" select="normalize-space(pxs:DocumentScope)"/>
      <xsl:variable name="rr" select="normalize-space(pxs:ReporterRole)"/>
      <xsl:variable name="rtCount" select="count(pxs:ReportedTransaction)"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:CustomizationID                        or self::cbc:ProfileID                        or self::cbc:UUID                        or self::cbc:IssueDate                        or self::cbc:IssueTime                        or self::pxs:DocumentTypeCode                        or self::pxs:DocumentScope                        or self::pxs:TaxAuthority                        or self::pxs:ReporterRole                        or self::pxs:ReportingParty                        or self::pxs:ReceivingParty                        or self::pxs:ReportersRepresentative                        or self::pxs:ReportedTransaction                        or self::pxs:ReportedDocument)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:CustomizationID or self::cbc:ProfileID or self::cbc:UUID or self::cbc:IssueDate or self::cbc:IssueTime or self::pxs:DocumentTypeCode or self::pxs:DocumentScope or self::pxs:TaxAuthority or self::pxs:ReporterRole or self::pxs:ReportingParty or self::pxs:ReceivingParty or self::pxs:ReportersRepresentative or self::pxs:ReportedTransaction or self::pxs:ReportedDocument)]) = 0">
               <xsl:attribute name="id">ibr-tdd-00</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-00] – The pxs:TaxData element MUST NOT contain elements other than
        cbc:CustomizationID, cbc:ProfileID, cbc:UUID, cbc:IssueDate, cbc:IssueTime,
        pxs:DocumentTypeCode, pxs:DocumentScope,
        pxs:TaxAuthority, pxs:ReporterRole, pxs:ReportingParty, pxs:ReceivingParty,
        pxs:ReportersRepresentative, pxs:ReportedTransaction, and pxs:ReportedDocument.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="normalize-space(cbc:CustomizationID) =               'urn:peppol:taxdata:ViDA-1'"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="normalize-space(cbc:CustomizationID) = 'urn:peppol:taxdata:ViDA-1'">
               <xsl:attribute name="id">ibr-tdd-01</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-01] – The cbc:CustomizationID element MUST have the value
        'urn:peppol:taxdata:ViDA-1'.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="normalize-space(cbc:ProfileID) = 'urn:peppol:taxreporting'"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="normalize-space(cbc:ProfileID) = 'urn:peppol:taxreporting'">
               <xsl:attribute name="id">ibr-tdd-02</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-02] – The cbc:ProfileID element MUST have the value 'urn:peppol:taxreporting'.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cbc:UUID)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl" test="exists(cbc:UUID)">
               <xsl:attribute name="id">ibr-tdd-03</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-03] – The cbc:UUID element MUST be present.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="string-length(normalize-space(cbc:IssueDate)) = 10"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="string-length(normalize-space(cbc:IssueDate)) = 10">
               <xsl:attribute name="id">ibr-tdd-04</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-04] – The cbc:IssueDate element MUST NOT contain timezone information.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="matches(       normalize-space(cbc:IssueTime),       '^(?:([01]\d|2[0-3]):[0-5]\d:[0-5]\d|24:00:00)(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?$'     )"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="matches( normalize-space(cbc:IssueTime), '^(?:([01]\d|2[0-3]):[0-5]\d:[0-5]\d|24:00:00)(\.\d+)?(?:Z|[+-]\d{2}:\d{2})?$' )">
               <xsl:attribute name="id">ibr-tdd-05</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-05] – The cbc:IssueTime element MUST contain timezone information.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="not(contains($dtc, ' ')) and contains($cl_dtc, concat(' ', $dtc, ' '))"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="not(contains($dtc, ' ')) and contains($cl_dtc, concat(' ', $dtc, ' '))">
               <xsl:attribute name="id">ibr-tdd-06</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
	[ibr-tdd-06] – The pxs:DocumentTypeCode element MUST be coded according to the applicable code list.
</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="not(contains($ds, ' ')) and contains($cl_ds, concat(' ', $ds, ' '))"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="not(contains($ds, ' ')) and contains($cl_ds, concat(' ', $ds, ' '))">
               <xsl:attribute name="id">ibr-tdd-08</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
	[ibr-tdd-08] – The pxs:DocumentScope element MUST be coded according to the applicable code list.
</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="not(contains($rr, ' ')) and contains($cl_rr, concat(' ', $rr, ' '))"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="not(contains($rr, ' ')) and contains($cl_rr, concat(' ', $rr, ' '))">
               <xsl:attribute name="id">ibr-tdd-09</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
	[ibr-tdd-09] – The pxs:ReporterRole element MUST be coded according to the applicable code list.
</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(pxs:TaxAuthority)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl" test="exists(pxs:TaxAuthority)">
               <xsl:attribute name="id">ibr-tdd-10</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-10] – The pxs:TaxData element MUST contain a pxs:TaxAuthority element.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(pxs:ReportedTransaction) = 1"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(pxs:ReportedTransaction) = 1">
               <xsl:attribute name="id">ibr-tdd-11</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-11] – Exactly one pxs:ReportedTransaction element MUST be present.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:TaxData/pxs:TaxAuthority" priority="1050" mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:TaxData/pxs:TaxAuthority"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID or self::cbc:Name)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID or self::cbc:Name)]) = 0">
               <xsl:attribute name="id">ibr-tdd-12</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-12] – The pxs:TaxAuthority element MUST NOT contain elements other than
        cbc:ID and cbc:Name.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cbc:ID)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl" test="exists(cbc:ID)">
               <xsl:attribute name="id">ibr-tdd-13</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-13] – The pxs:TaxAuthority element MUST contain the cbc:ID element.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="/pxs:TaxData/pxs:ReportingParty" priority="1049" mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="/pxs:TaxData/pxs:ReportingParty"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:EndpointID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:EndpointID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-14</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-14] – The pxs:ReportingParty element MUST NOT contain elements other than
        cbc:EndpointID.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cbc:EndpointID)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl" test="exists(cbc:EndpointID)">
               <xsl:attribute name="id">ibr-tdd-15</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-15] – The cbc:EndpointID element of pxs:ReportingParty MUST be present.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cbc:EndpointID/@schemeID)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="exists(cbc:EndpointID/@schemeID)">
               <xsl:attribute name="id">ibr-tdd-16</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-16] – The scheme identifier attribute of cbc:EndpointID MUST be present.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="not(exists(cbc:EndpointID/@schemeID))               or matches(cbc:EndpointID/@schemeID, $regex_pidscheme)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="not(exists(cbc:EndpointID/@schemeID)) or matches(cbc:EndpointID/@schemeID, $regex_pidscheme)">
               <xsl:attribute name="id">ibr-tdd-17</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-17] – The scheme identifier attribute of cbc:EndpointID MUST be a
        Peppol Participant Identifier Scheme.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="/pxs:TaxData/pxs:ReceivingParty" priority="1048" mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="/pxs:TaxData/pxs:ReceivingParty"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:EndpointID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:EndpointID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-18</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-18] – The pxs:ReceivingParty element MUST NOT contain elements other than
        cbc:EndpointID.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cbc:EndpointID)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl" test="exists(cbc:EndpointID)">
               <xsl:attribute name="id">ibr-tdd-19</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-19] – The cbc:EndpointID element of pxs:ReceivingParty MUST be present.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cbc:EndpointID/@schemeID)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="exists(cbc:EndpointID/@schemeID)">
               <xsl:attribute name="id">ibr-tdd-20</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
        [ibr-tdd-20] – The scheme identifier attribute of cbc:EndpointID MUST be present.
      </svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="/pxs:TaxData/pxs:ReportersRepresentative"
                 priority="1047"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="/pxs:TaxData/pxs:ReportersRepresentative"/>
      <xsl:variable name="pidCount" select="count(cac:PartyIdentification/cbc:ID)"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:PartyIdentification)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:PartyIdentification)]) = 0">
               <xsl:attribute name="id">ibr-tdd-21</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-21] – The cac:ReportersRepresentative element MUST NOT contain elements other than cac:PartyIdentification.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="$pidCount = 1"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl" test="$pidCount = 1">
               <xsl:attribute name="id">ibr-tdd-22</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
				[ibr-tdd-22] – Exactly one cbc:ID element MUST be present within cac:PartyIdentification 
				<xsl:text/>
                  <xsl:value-of select="$pidCount"/>
                  <xsl:text/>
				instead
			</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cac:PartyIdentification/cbc:ID/@schemeID)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="exists(cac:PartyIdentification/cbc:ID/@schemeID)">
               <xsl:attribute name="id">ibr-tdd-23</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-23] – The scheme identifier attribute of cac:PartyIdentification/cbc:ID MUST be present.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="/pxs:TaxData/pxs:ReportedTransaction"
                 priority="1046"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="/pxs:TaxData/pxs:ReportedTransaction"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(pxs:ReportedDocument)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="exists(pxs:ReportedDocument)">
               <xsl:attribute name="id">ibr-tdd-24</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-24] – The cac:ReportedDocument element MUST be present.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument" priority="1045" mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl" context="pxs:ReportedDocument"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(          self::cbc:CustomizationID          or self::cbc:ProfileID          or self::cbc:ID          or self::cbc:UUID          or self::cbc:IssueDate          or self::pxs:DocumentTypeCode          or self::cbc:Note    or self::cbc:TaxPointDate          or self::cbc:DocumentCurrencyCode          or self::cbc:TaxCurrencyCode          or self::cac:InvoicePeriod          or self::cac:BillingReference          or self::cac:AccountingSupplierParty          or self::cac:AccountingCustomerParty          or self::cac:TaxRepresentativeParty or self::cac:Delivery          or self::cac:PaymentMeans          or self::cac:AllowanceCharge          or self::cac:TaxTotal          or self::pxs:MonetaryTotal          or self::pxs:DocumentLine       )]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not( self::cbc:CustomizationID or self::cbc:ProfileID or self::cbc:ID or self::cbc:UUID or self::cbc:IssueDate or self::pxs:DocumentTypeCode or self::cbc:Note or self::cbc:TaxPointDate or self::cbc:DocumentCurrencyCode or self::cbc:TaxCurrencyCode or self::cac:InvoicePeriod or self::cac:BillingReference or self::cac:AccountingSupplierParty or self::cac:AccountingCustomerParty or self::cac:TaxRepresentativeParty or self::cac:Delivery or self::cac:PaymentMeans or self::cac:AllowanceCharge or self::cac:TaxTotal or self::pxs:MonetaryTotal or self::pxs:DocumentLine )]) = 0">
               <xsl:attribute name="id">ibr-tdd-25</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-25] – The cac:ReportedDocument element MUST NOT contain elements other than
cbc:CustomizationID, cbc:ProfileID, cbc:ID, cbc:UUID, cbc:IssueDate, pxs:DocumentTypeCode, cbc:Note, cbc:TaxPointDate, cbc:DocumentCurrencyCode, cbc:TaxCurrencyCode, cac:InvoicePeriod, cac:BillingReference, cac:AccountingSupplierParty, cac:AccountingCustomerParty, cac:TaxRepresentativeParty, cac:Delivery, cac:PaymentMeans, cac:AllowanceCharge, cac:TaxTotal, pxs:MonetaryTotal, and pxs:DocumentLine.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:InvoicePeriod"
                 priority="1044"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:InvoicePeriod"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:StartDate or self::cbc:EndDate or self::cbc:DescriptionCode)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:StartDate or self::cbc:EndDate or self::cbc:DescriptionCode)]) = 0">
               <xsl:attribute name="id">ibr-tdd-26</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-26] – The cac:InvoicePeriod element MUST NOT contain elements other than cbc:StartDate, cbc:EndDate, and cbc:DescriptionCode.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:DocumentLine/cac:InvoicePeriod"
                 priority="1043"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:DocumentLine/cac:InvoicePeriod"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:StartDate or self::cbc:EndDate)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:StartDate or self::cbc:EndDate)]) = 0">
               <xsl:attribute name="id">ibr-tdd-27</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-27] – The cac:InvoicePeriod element at line level, MUST NOT contain elements other than cbc:StartDate and cbc:EndDate.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:BillingReference/cac:InvoiceDocumentReference"
                 priority="1042"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:BillingReference/cac:InvoiceDocumentReference"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID or self::cbc:IssueDate)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID or self::cbc:IssueDate)]) = 0">
               <xsl:attribute name="id">ibr-tdd-28</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-28] – The cac:InvoiceDocumentReference element MUST NOT contain elements other than cbc:ID and cbc:IssueDate.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="/pxs:TaxData/pxs:ReportedTransaction/pxs:ReportedDocument/cac:AccountingSupplierParty"
                 priority="1041"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="/pxs:TaxData/pxs:ReportedTransaction/pxs:ReportedDocument/cac:AccountingSupplierParty"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cac:Party)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl" test="exists(cac:Party)">
               <xsl:attribute name="id">ibr-tdd-29</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-29] – The SELLER (ibg-04) MUST be present.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingSupplierParty/cac:Party"
                 priority="1040"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingSupplierParty/cac:Party"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:PostalAddress or self::cac:PartyTaxScheme)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:PostalAddress or self::cac:PartyTaxScheme)]) = 0">
               <xsl:attribute name="id">ibr-tdd-30</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-30] – The cac:Party element MUST NOT contain elements other than cac:PostalAddress and optionally cac:PartyTaxScheme.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress"
                 priority="1039"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:Country)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:Country)]) = 0">
               <xsl:attribute name="id">ibr-tdd-31</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-31] – The cac:PostalAddress element MUST NOT contain elements other than cac:Country.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country"
                 priority="1038"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingSupplierParty/cac:Party/cac:PostalAddress/cac:Country"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:IdentificationCode)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:IdentificationCode)]) = 0">
               <xsl:attribute name="id">ibr-tdd-32</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-32] – The cac:Country element MUST NOT contain elements other than cbc:IdentificationCode.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme"
                 priority="1037"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="cac:TaxScheme/cbc:ID = 'VAT'"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="cac:TaxScheme/cbc:ID = 'VAT'">
               <xsl:attribute name="id">ibr-tdd-33</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-33] – The value of cac:PartyTaxScheme/cac:TaxScheme/cbc:ID MUST be VAT.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:CompanyID or self::cac:TaxScheme)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:CompanyID or self::cac:TaxScheme)]) = 0">
               <xsl:attribute name="id">ibr-tdd-34</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-34] – The cac:PartyTaxScheme element MUST NOT contain elements other than cbc:CompanyID and cac:TaxScheme.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme"
                 priority="1036"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingSupplierParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-35</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>[ibr-tdd-35] – The cac:TaxScheme element MUST NOT contain elements other than cbc:ID.</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="/pxs:TaxData/pxs:ReportedTransaction/pxs:ReportedDocument/cac:AccountingCustomerParty"
                 priority="1035"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="/pxs:TaxData/pxs:ReportedTransaction/pxs:ReportedDocument/cac:AccountingCustomerParty"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="exists(cac:Party)"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl" test="exists(cac:Party)">
               <xsl:attribute name="id">ibr-tdd-36</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-36] – The BUYER (ibg-07) MUST be present.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:Party)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:Party)]) = 0">
               <xsl:attribute name="id">ibr-tdd-37</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-37] – The cac:AccountingCustomerParty element MUST NOT contain elements other than cac:Party.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingCustomerParty/cac:Party"
                 priority="1034"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingCustomerParty/cac:Party"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:PostalAddress or self::cac:PartyTaxScheme or self::cac:PartyLegalEntity)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:PostalAddress or self::cac:PartyTaxScheme or self::cac:PartyLegalEntity)]) = 0">
               <xsl:attribute name="id">ibr-tdd-38</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-38] – The cac:Party element MUST NOT contain elements other than
		cac:PostalAddress, cac:PartyLegalEntity, and optionally cac:PartyTaxScheme.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress"
                 priority="1033"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:Country)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:Country)]) = 0">
               <xsl:attribute name="id">ibr-tdd-39</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-39] – The cac:PostalAddress element MUST NOT contain elements other than cac:Country.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cac:Country"
                 priority="1032"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingCustomerParty/cac:Party/cac:PostalAddress/cac:Country"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:IdentificationCode)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:IdentificationCode)]) = 0">
               <xsl:attribute name="id">ibr-tdd-40</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-40] – The cac:Country element MUST NOT contain elements other than cbc:IdentificationCode.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme"
                 priority="1031"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="cac:TaxScheme/cbc:ID = 'VAT'"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="cac:TaxScheme/cbc:ID = 'VAT'">
               <xsl:attribute name="id">ibr-tdd-41</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-41] – The value of cac:PartyTaxScheme/cac:TaxScheme/cbc:ID MUST be 'VAT'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:CompanyID or self::cac:TaxScheme)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:CompanyID or self::cac:TaxScheme)]) = 0">
               <xsl:attribute name="id">ibr-tdd-42</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-42] – The cac:PartyTaxScheme element MUST NOT contain elements other than
		cbc:CompanyID and cac:TaxScheme.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme"
                 priority="1030"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingCustomerParty/cac:Party/cac:PartyTaxScheme/cac:TaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-43</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-43] – The cac:TaxScheme element MUST NOT contain elements other than cbc:ID.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity"
                 priority="1029"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingCustomerParty/cac:Party/cac:PartyLegalEntity"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:RegistrationName)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:RegistrationName)]) = 0">
               <xsl:attribute name="id">ibr-tdd-86</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-86] – The cac:PartyLegalEntity element MUST NOT contain elements other than
		cbc:RegistrationName.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:AccountingCustomerParty/cac:TaxRepresentativeParty"
                 priority="1028"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:AccountingCustomerParty/cac:TaxRepresentativeParty"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:PostalAddress or self::cac:PartyTaxScheme)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:PostalAddress or self::cac:PartyTaxScheme)]) = 0">
               <xsl:attribute name="id">ibr-tdd-44</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-44] – The cac:TaxRepresentativeParty element MUST NOT contain elements other than
		cac:PostalAddress and optionally cac:PartyTaxScheme.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:TaxRepresentativeParty/cac:PostalAddress"
                 priority="1027"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:TaxRepresentativeParty/cac:PostalAddress"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:Country)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:Country)]) = 0">
               <xsl:attribute name="id">ibr-tdd-45</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-45] – The cac:PostalAddress element MUST NOT contain elements other than cac:Country.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:TaxRepresentativeParty/cac:PostalAddress/cac:Country"
                 priority="1026"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:TaxRepresentativeParty/cac:PostalAddress/cac:Country"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:IdentificationCode)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:IdentificationCode)]) = 0">
               <xsl:attribute name="id">ibr-tdd-46</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-46] – The cac:Country element MUST NOT contain elements other than cbc:IdentificationCode.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:Delivery" priority="1025" mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl" context="cac:Delivery"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ActualDeliveryDate)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ActualDeliveryDate)]) = 0">
               <xsl:attribute name="id">ibr-tdd-85</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-85] – The cac:Delivery element MUST NOT contain elements other than
		cbc:ActualDeliveryDate.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:TaxRepresentativeParty/cac:PartyTaxScheme"
                 priority="1024"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:TaxRepresentativeParty/cac:PartyTaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="cac:TaxScheme/cbc:ID = 'VAT'"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="cac:TaxScheme/cbc:ID = 'VAT'">
               <xsl:attribute name="id">ibr-tdd-47</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-47] – The value of cac:PartyTaxScheme/cac:TaxScheme/cbc:ID MUST be 'VAT'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:CompanyID or self::cac:TaxScheme)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:CompanyID or self::cac:TaxScheme)]) = 0">
               <xsl:attribute name="id">ibr-tdd-48</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-48] – The cac:PartyTaxScheme element MUST NOT contain elements other than cbc:CompanyID and cac:TaxScheme.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="cac:TaxRepresentativeParty/cac:PartyTaxScheme/cac:TaxScheme"
                 priority="1023"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="cac:TaxRepresentativeParty/cac:PartyTaxScheme/cac:TaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-49</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-49] – The cac:TaxScheme element MUST NOT contain elements other than cbc:ID.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:PaymentMeans"
                 priority="1022"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:PaymentMeans"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(              self::cbc:PaymentMeansCode              or self::cbc:PaymentID              or self::cac:CardAccount              or self::cac:PayeeFinancialAccount              or self::cac:PaymentMandate          )]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not( self::cbc:PaymentMeansCode or self::cbc:PaymentID or self::cac:CardAccount or self::cac:PayeeFinancialAccount or self::cac:PaymentMandate )]) = 0">
               <xsl:attribute name="id">ibr-tdd-50</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-50] – The cac:PaymentMeans element MUST NOT contain elements other than
		cbc:PaymentMeansCode, cbc:PaymentID, cac:CardAccount,
		cac:PayeeFinancialAccount, and cac:PaymentMandate.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:PaymentMeans/cbc:PaymentMeansCode"
                 priority="1021"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:PaymentMeans/cbc:PaymentMeansCode"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(@*[not(local-name() = 'name')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(@*[not(local-name() = 'name')]) = 0">
               <xsl:attribute name="id">ibr-tdd-51</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-51] – The cbc:PaymentMeansCode element MUST NOT have attributes other than 'name'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:PaymentMeans/cac:CardAccount"
                 priority="1020"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:PaymentMeans/cac:CardAccount"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:PrimaryAccountNumberID                        or self::cbc:NetworkID                        or self::cbc:HolderName)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:PrimaryAccountNumberID or self::cbc:NetworkID or self::cbc:HolderName)]) = 0">
               <xsl:attribute name="id">ibr-tdd-52</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-52] – The cac:CardAccount element MUST NOT contain elements other than
		cbc:PrimaryAccountNumberID, cbc:NetworkID, and cbc:HolderName.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:PaymentMeans/cac:PayeeFinancialAccount"
                 priority="1019"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:PaymentMeans/cac:PayeeFinancialAccount"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID or self::cac:FinancialInstitutionBranch)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID or self::cac:FinancialInstitutionBranch)]) = 0">
               <xsl:attribute name="id">ibr-tdd-53</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-53] – The cac:PayeeFinancialAccount element MUST NOT contain elements other than
		cbc:ID and cac:FinancialInstitutionBranch.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:PaymentMeans/cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch"
                 priority="1018"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:PaymentMeans/cac:PayeeFinancialAccount/cac:FinancialInstitutionBranch"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-54</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-54] – The cac:FinancialInstitutionBranch element MUST NOT contain elements other than
		cbc:ID.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:PaymentMeans/cac:PaymentMandate"
                 priority="1017"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:PaymentMeans/cac:PaymentMandate"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID or self::cac:PayerFinancialAccount)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID or self::cac:PayerFinancialAccount)]) = 0">
               <xsl:attribute name="id">ibr-tdd-55</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-55] – The cac:PaymentMandate element MUST NOT contain elements other than
		cbc:ID and cac:PayerFinancialAccount.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:PaymentMeans/cac:PaymentMandate/cac:PayerFinancialAccount"
                 priority="1016"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:PaymentMeans/cac:PaymentMandate/cac:PayerFinancialAccount"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-56</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-56] – The cac:PayerFinancialAccount element MUST NOT contain elements other than
		cbc:ID.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:AllowanceCharge"
                 priority="1015"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:AllowanceCharge"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(              self::cbc:ChargeIndicator              or self::cbc:AllowanceChargeReasonCode              or self::cbc:AllowanceChargeReason              or self::cbc:MultiplierFactorNumeric              or self::cbc:Amount              or self::cbc:BaseAmount              or self::cac:TaxCategory          )]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not( self::cbc:ChargeIndicator or self::cbc:AllowanceChargeReasonCode or self::cbc:AllowanceChargeReason or self::cbc:MultiplierFactorNumeric or self::cbc:Amount or self::cbc:BaseAmount or self::cac:TaxCategory )]) = 0">
               <xsl:attribute name="id">ibr-tdd-57</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-57] – The cac:AllowanceCharge element MUST NOT contain elements other than
		cbc:ChargeIndicator, cbc:AllowanceChargeReasonCode, cbc:AllowanceChargeReason,
		cbc:MultiplierFactorNumeric, cbc:Amount, cbc:BaseAmount, and cac:TaxCategory.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:Amount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:Amount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-58</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-58] – The cbc:Amount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:BaseAmount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:BaseAmount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-59</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-59] – The cbc:BaseAmount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:DocumentLine/cac:AllowanceCharge"
                 priority="1014"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:DocumentLine/cac:AllowanceCharge"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(              self::cbc:ChargeIndicator              or self::cbc:AllowanceChargeReasonCode              or self::cbc:AllowanceChargeReason              or self::cbc:MultiplierFactorNumeric              or self::cbc:Amount              or self::cbc:BaseAmount          )]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not( self::cbc:ChargeIndicator or self::cbc:AllowanceChargeReasonCode or self::cbc:AllowanceChargeReason or self::cbc:MultiplierFactorNumeric or self::cbc:Amount or self::cbc:BaseAmount )]) = 0">
               <xsl:attribute name="id">ibr-tdd-60</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-60] – The cac:AllowanceCharge element MUST NOT contain elements other than
		cbc:ChargeIndicator, cbc:AllowanceChargeReasonCode, cbc:AllowanceChargeReason,
		cbc:MultiplierFactorNumeric, cbc:Amount, and cbc:BaseAmount.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:Amount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:Amount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-61</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-61] – The cbc:Amount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:BaseAmount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:BaseAmount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-62</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-62] – The cbc:BaseAmount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:AllowanceCharge/cac:TaxCategory"
                 priority="1013"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:AllowanceCharge/cac:TaxCategory"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID or self::cbc:Percent or self::cac:TaxScheme)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID or self::cbc:Percent or self::cac:TaxScheme)]) = 0">
               <xsl:attribute name="id">ibr-tdd-63</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-63] – The cac:TaxCategory element MUST NOT contain elements other than
		cbc:ID, cbc:Percent, and cac:TaxScheme.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:AllowanceCharge/cac:TaxCategory/cac:TaxScheme"
                 priority="1012"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:AllowanceCharge/cac:TaxCategory/cac:TaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-64</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-64] – The cac:TaxScheme element MUST NOT contain elements other than cbc:ID.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:TaxTotal"
                 priority="1011"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:TaxTotal"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:TaxAmount or self::cac:TaxSubtotal)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:TaxAmount or self::cac:TaxSubtotal)]) = 0">
               <xsl:attribute name="id">ibr-tdd-65</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-65] – The cac:TaxTotal element MUST NOT contain elements other than
		cbc:TaxAmount and cac:TaxSubtotal.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:TaxAmount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:TaxAmount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-66</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-66] – The cbc:TaxAmount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:TaxTotal/cac:TaxSubtotal"
                 priority="1010"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:TaxTotal/cac:TaxSubtotal"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:TaxableAmount or self::cbc:TaxAmount or self::cac:TaxCategory)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:TaxableAmount or self::cbc:TaxAmount or self::cac:TaxCategory)]) = 0">
               <xsl:attribute name="id">ibr-tdd-67</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-67] – The cac:TaxSubtotal element MUST NOT contain elements other than
		cbc:TaxableAmount, cbc:TaxAmount, and cac:TaxCategory.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:TaxableAmount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:TaxableAmount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-68</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-68] – The cbc:TaxableAmount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:TaxAmount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:TaxAmount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-69</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-69] – The cbc:TaxAmount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory"
                 priority="1009"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(              self::cbc:ID              or self::cbc:Percent              or self::cbc:TaxExemptionReasonCode              or self::cbc:TaxExemptionReason              or self::cac:TaxScheme          )]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not( self::cbc:ID or self::cbc:Percent or self::cbc:TaxExemptionReasonCode or self::cbc:TaxExemptionReason or self::cac:TaxScheme )]) = 0">
               <xsl:attribute name="id">ibr-tdd-70</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-70] – The cac:TaxCategory element MUST NOT contain elements other than
		cbc:ID, cbc:Percent, cbc:TaxExemptionReasonCode,
		cbc:TaxExemptionReason, and cac:TaxScheme.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme"
                 priority="1008"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:TaxTotal/cac:TaxSubtotal/cac:TaxCategory/cac:TaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-71</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-71] – The cac:TaxScheme element MUST NOT contain elements other than cbc:ID.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:MonetaryTotal"
                 priority="1007"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:MonetaryTotal"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(              self::cbc:LineExtensionAmount              or self::cbc:TaxExclusiveAmount              or self::cbc:TaxInclusiveAmount              or self::cbc:AllowanceTotalAmount              or self::cbc:ChargeTotalAmount              or self::cbc:PrepaidAmount              or self::cbc:PayableAmount          )]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not( self::cbc:LineExtensionAmount or self::cbc:TaxExclusiveAmount or self::cbc:TaxInclusiveAmount or self::cbc:AllowanceTotalAmount or self::cbc:ChargeTotalAmount or self::cbc:PrepaidAmount or self::cbc:PayableAmount )]) = 0">
               <xsl:attribute name="id">ibr-tdd-72</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-72] – The pxs:MonetaryTotal element MUST NOT contain elements other than
		cbc:LineExtensionAmount, cbc:TaxExclusiveAmount, cbc:TaxInclusiveAmount,
		cbc:AllowanceTotalAmount, cbc:ChargeTotalAmount, cbc:PrepaidAmount,
		and cbc:PayableAmount.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[                self::cbc:LineExtensionAmount                or self::cbc:TaxExclusiveAmount                or self::cbc:TaxInclusiveAmount                or self::cbc:AllowanceTotalAmount                or self::cbc:ChargeTotalAmount                or self::cbc:PrepaidAmount                or self::cbc:PayableAmount              ]/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[ self::cbc:LineExtensionAmount or self::cbc:TaxExclusiveAmount or self::cbc:TaxInclusiveAmount or self::cbc:AllowanceTotalAmount or self::cbc:ChargeTotalAmount or self::cbc:PrepaidAmount or self::cbc:PayableAmount ]/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-73</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-73] – All amount elements within pxs:MonetaryTotal MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:DocumentLine"
                 priority="1006"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:DocumentLine"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(              self::cbc:ID              or self::cbc:Note              or self::cbc:InvoicedQuantity              or self::cbc:LineExtensionAmount              or self::cac:InvoicePeriod              or self::cac:AllowanceCharge              or self::cac:Item              or self::cac:Price          )]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not( self::cbc:ID or self::cbc:Note or self::cbc:InvoicedQuantity or self::cbc:LineExtensionAmount or self::cac:InvoicePeriod or self::cac:AllowanceCharge or self::cac:Item or self::cac:Price )]) = 0">
               <xsl:attribute name="id">ibr-tdd-74</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-74] – The pxs:DocumentLine element MUST NOT contain elements other than
		cbc:ID, cbc:Note, cbc:InvoicedQuantity, cbc:LineExtensionAmount,
		cac:InvoicePeriod, cac:AllowanceCharge, cac:Item, and cac:Price.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:InvoicedQuantity/@*[not(local-name() = 'unitCode')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:InvoicedQuantity/@*[not(local-name() = 'unitCode')]) = 0">
               <xsl:attribute name="id">ibr-tdd-75</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-75] – The cbc:InvoicedQuantity element MUST have the attribute 'unitCode'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:LineExtensionAmount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:LineExtensionAmount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-76</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-76] – The cbc:LineExtensionAmount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:DocumentLine/cac:Item"
                 priority="1005"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:DocumentLine/cac:Item"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:Description                        or self::cbc:Name                        or self::cac:CommodityClassification                        or self::cac:ClassifiedTaxCategory)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:Description or self::cbc:Name or self::cac:CommodityClassification or self::cac:ClassifiedTaxCategory)]) = 0">
               <xsl:attribute name="id">ibr-tdd-77</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-77] – The cac:Item element MUST NOT contain elements other than
		cbc:Description, cbc:Name, cac:CommodityClassification, and cac:ClassifiedTaxCategory.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:DocumentLine/cac:Item/cac:CommodityClassification"
                 priority="1004"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:DocumentLine/cac:Item/cac:CommodityClassification"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ItemClassificationCode)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ItemClassificationCode)]) = 0">
               <xsl:attribute name="id">ibr-tdd-78</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-78] – The cac:CommodityClassification element MUST NOT contain elements other than
		cbc:ItemClassificationCode.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:ItemClassificationCode/@*[not(local-name() = 'listID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:ItemClassificationCode/@*[not(local-name() = 'listID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-79</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-79] – The cbc:ItemClassificationCode element MUST have the attribute 'listID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:DocumentLine/cac:Item/cac:ClassifiedTaxCategory"
                 priority="1003"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:DocumentLine/cac:Item/cac:ClassifiedTaxCategory"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID or self::cbc:Percent or self::cac:TaxScheme)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID or self::cbc:Percent or self::cac:TaxScheme)]) = 0">
               <xsl:attribute name="id">ibr-tdd-80</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-80] – The cac:ClassifiedTaxCategory element MUST NOT contain elements other than
		cbc:ID, cbc:Percent, and cac:TaxScheme.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:DocumentLine/cac:Item/cac:ClassifiedTaxCategory/cac:TaxScheme"
                 priority="1002"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:DocumentLine/cac:Item/cac:ClassifiedTaxCategory/cac:TaxScheme"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:ID)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:ID)]) = 0">
               <xsl:attribute name="id">ibr-tdd-81</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-81] – The cac:TaxScheme element MUST NOT contain elements other than cbc:ID.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/pxs:DocumentLine/cac:Price"
                 priority="1001"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/pxs:DocumentLine/cac:Price"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cbc:PriceAmount)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cbc:PriceAmount)]) = 0">
               <xsl:attribute name="id">ibr-tdd-82</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-82] – The cac:Price element MUST NOT contain elements other than
		cbc:PriceAmount.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(cbc:PriceAmount/@*[not(local-name() = 'currencyID')]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(cbc:PriceAmount/@*[not(local-name() = 'currencyID')]) = 0">
               <xsl:attribute name="id">ibr-tdd-83</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-83] – The cbc:PriceAmount element MUST have the attribute 'currencyID'.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <!--RULE -->
   <xsl:template match="pxs:ReportedDocument/cac:BillingReference"
                 priority="1000"
                 mode="M10">
      <svrl:fired-rule xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                       context="pxs:ReportedDocument/cac:BillingReference"/>
      <!--ASSERT -->
      <xsl:choose>
         <xsl:when test="count(*[not(self::cac:InvoiceDocumentReference)]) = 0"/>
         <xsl:otherwise>
            <svrl:failed-assert xmlns:svrl="http://purl.oclc.org/dsdl/svrl"
                                test="count(*[not(self::cac:InvoiceDocumentReference)]) = 0">
               <xsl:attribute name="id">ibr-tdd-84</xsl:attribute>
               <xsl:attribute name="flag">fatal</xsl:attribute>
               <xsl:attribute name="location">
                  <xsl:apply-templates select="." mode="schematron-select-full-path"/>
               </xsl:attribute>
               <svrl:text>
		[ibr-tdd-84] – The cac:BillingReference element MUST NOT contain elements other than
		cac:InvoiceDocumentReference.
	</svrl:text>
            </svrl:failed-assert>
         </xsl:otherwise>
      </xsl:choose>
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
   <xsl:template match="text()" priority="-1" mode="M10"/>
   <xsl:template match="@*|node()" priority="-2" mode="M10">
      <xsl:apply-templates select="*|comment()|processing-instruction()" mode="M10"/>
   </xsl:template>
</xsl:stylesheet>
